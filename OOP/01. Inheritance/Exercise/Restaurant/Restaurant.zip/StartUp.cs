﻿using System;

namespace Restaurant
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Cake cake = new Cake("Garaj");
            Fish fish = new Fish("cacka", 1.50m);
            Tea tea = new Tea("zelen", 1.2m, 100);
            Coffee cafe = new Coffee("Lavacka", 4.2);

            Console.WriteLine(cake.Grams);
            Console.WriteLine(fish.Grams);
            Console.WriteLine(tea.Milliliters);
            Console.WriteLine(cafe.Milliliters);
            Console.WriteLine(cafe.Caffeine);
        }
    }
}
