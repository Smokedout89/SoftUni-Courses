﻿namespace BorderControl.Contracts
{
    interface IIdentifiable
    {
        public string Id { get; }
    }
}
