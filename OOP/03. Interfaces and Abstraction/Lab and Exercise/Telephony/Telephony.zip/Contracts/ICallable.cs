﻿namespace Telephony.Contracts
{
    interface ICallable
    {
        string Call(string number);
    }
}
