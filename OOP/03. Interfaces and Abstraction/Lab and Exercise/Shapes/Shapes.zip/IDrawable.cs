﻿namespace Shapes
{
    public interface IDrawable
    {
        void Draw();
    }
}
