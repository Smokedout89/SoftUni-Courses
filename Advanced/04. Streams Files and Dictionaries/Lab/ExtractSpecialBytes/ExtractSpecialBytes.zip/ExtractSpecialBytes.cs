﻿//namespace ExtractSpecialBytes
//{
//    using System;
//    using System.IO;
//    using System.Text;
//    using System.Collections.Generic;
//    public class ExtractSpecialBytes
//    {
//        static void Main()
//        {
//            string binaryFilePath = @"..\..\..\Files\example.png";
//            string bytesFilePath = @"..\..\..\Files\bytes.txt";
//            string outputPath = @"..\..\..\Files\output.bin";

//            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
//        }

//        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
//        {
//            using StreamReader streamReader = new StreamReader(bytesFilePath);
//            byte[] fileBytes = File.ReadAllBytes(binaryFilePath);
//            var bytesList = new List<String>();
//            var sb = new StringBuilder();

//            while (!streamReader.EndOfStream)
//            {
//                bytesList.Add(streamReader.ReadLine());
//            }
//            foreach (var item in fileBytes)
//            {
//                if (bytesList.Contains(item.ToString()))
//                {
//                    sb.AppendLine(item.ToString());
//                }

//            }
//            using StreamWriter file = new StreamWriter(outputPath); ;
//            file.WriteLine(sb.ToString().Trim());
//        }
//    }
//}

namespace ExtractBytes
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Text;

    public class ExtractBytes
    {
        static void Main(string[] args)
        {
            const string binaryFilePath = @"..\..\..\Files\example.png";
            const string bytesFilePath = @"..\..\..\Files\bytes.txt";
            const string outputPath = @"..\..\..\Files\output.bin";

            ExtractBytesFromBinaryFile(binaryFilePath, bytesFilePath, outputPath);
        }

        public static void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
        {
            StringBuilder sb = new StringBuilder();
            using (StreamReader readerBit = new StreamReader(bytesFilePath))
            {
                while (!readerBit.EndOfStream)
                {
                    sb.Append(readerBit.ReadLine() + " ");
                }
            }

            byte[] bytes = sb.ToString().Split(' ', StringSplitOptions.RemoveEmptyEntries).Select(byte.Parse).ToArray();


            using (FileStream reader = new FileStream(binaryFilePath, FileMode.Open))
            {
                byte[] buff = new byte[reader.Length];

                reader.Read(buff, 0, buff.Length);

                using (FileStream write = new FileStream(outputPath, FileMode.OpenOrCreate))
                {
                    foreach (byte item in buff)
                    {
                        if (bytes.Contains(item))
                        {
                            write.WriteByte(item);
                        }
                    }
                }
            }// using (FileStream reader = new FileStream(inputFileName, FileMode.Open)
        }// void ExtractBytesFromBinaryFile(string binaryFilePath, string bytesFilePath, string outputPath)
    }
}
