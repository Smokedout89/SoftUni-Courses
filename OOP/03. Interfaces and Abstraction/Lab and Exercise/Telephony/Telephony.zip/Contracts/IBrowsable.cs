﻿namespace Telephony.Contracts
{
    interface IBrowsable
    {
        string Browse(string url);
    }
}
