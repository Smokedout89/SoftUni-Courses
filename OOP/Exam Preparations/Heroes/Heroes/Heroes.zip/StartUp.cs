﻿namespace Heroes
{
    using System;

    using Core;
    using Core.Contracts;
    using Models.Weapons;

    public class StartUp
    {
        public static void Main()
        {
            IEngine engine = new Engine();
            engine.Run();
        }
    }
}
