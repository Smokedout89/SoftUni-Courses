﻿namespace BorderControl.Contracts
{
     interface IBirthdateable
    {
        public string Name { get; }

        public string Birthdate { get; }
    }
}
