﻿namespace WildFarm.Contracts
{
    public interface IMammal
    {
        public string LivingRegion { get; }
    }
}
