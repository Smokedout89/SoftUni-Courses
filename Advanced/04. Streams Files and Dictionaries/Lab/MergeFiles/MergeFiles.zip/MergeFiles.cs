﻿using System.Linq;
using System.Collections.Generic;

namespace MergeFiles
{
    using System;
    using System.IO;
    public class MergeFiles
    {
        static void Main()
        {
            var firstInputFilePath = @"..\..\..\Files\input1.txt";
            var secondInputFilePath = @"..\..\..\Files\input2.txt";
            var outputFilePath = @"..\..\..\Files\output.txt";

            MergeTextFiles(firstInputFilePath, secondInputFilePath, outputFilePath);
        }

        public static void MergeTextFiles(string firstInputFilePath, string secondInputFilePath, string outputFilePath)
        {
            //string folderPath = "";
            //string firstFileName = "FileOne.txt";
            //string secondFileName = "FileTwo.txt";

            //string firstFilePath = Path.Combine(folderPath, firstFileName);
            //string secondFilePath = Path.Combine(folderPath, secondFileName);

            List<string> mergedList = new List<string>();

            string[] firstFileLines = File.ReadAllLines(firstInputFilePath);
            string[] secondFileLines = File.ReadAllLines(secondInputFilePath);

            foreach (string line in firstFileLines)
            {
                mergedList.Add(line);
            }

            foreach (string line in secondFileLines)
            {
                mergedList.Add(line);
            }

           // string otputFilePath = "Output.txt";

            File.WriteAllLines(outputFilePath, mergedList.OrderBy(x => x));
        }
    }
}
