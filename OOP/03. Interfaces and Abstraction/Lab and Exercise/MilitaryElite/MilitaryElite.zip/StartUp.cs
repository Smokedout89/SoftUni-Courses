﻿using System;
using MilitaryElite.Core;

namespace MilitaryElite
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
