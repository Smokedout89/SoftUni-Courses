﻿using System;

namespace BoxOfT
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Box<string> box = new Box<string>();
            box.Add("1");
            box.Add("2");
            box.Add("esg");
            Console.WriteLine(box.Remove());
            box.Add("4");
            box.Add("asdf");
            Console.WriteLine(box.Remove());

        }
    }
}
