﻿namespace WildFarm.Contracts
{
    public interface IFeline
    {
        public string Breed { get; }
    }
}
