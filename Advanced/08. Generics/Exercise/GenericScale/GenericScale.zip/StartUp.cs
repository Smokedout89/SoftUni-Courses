﻿using System;

namespace GenericScale
{
    public class Program
    {
        static void Main(string[] args)
        {
            EqualityScale<string> asd = new EqualityScale<string>("gogi e 1ich" , "gogi e pich");

            Console.WriteLine(asd.AreEqual());
        }
    }
}
