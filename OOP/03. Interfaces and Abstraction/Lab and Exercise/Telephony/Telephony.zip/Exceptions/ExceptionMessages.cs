﻿namespace Telephony.Exceptions
{
    public class ExceptionMessages
    {
        public static string InvalidNumberException = "Invalid number!";

        public static string InvalidUrlException = "Invalid URL!";
    }
}
