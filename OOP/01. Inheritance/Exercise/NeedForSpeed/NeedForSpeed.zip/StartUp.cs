﻿using System;

namespace NeedForSpeed
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            RaceMotorcycle racem = new RaceMotorcycle(250, 100);
            racem.Drive(10);
            Console.WriteLine(racem.Fuel);
            CrossMotorcycle crossm = new CrossMotorcycle(200, 100);
            crossm.Drive(20);
            Console.WriteLine(crossm.Fuel);

            Vehicle sportcar = new SportCar(500, 100);
            Vehicle car = new Car(120, 100);

            sportcar.Drive(10);
            car.Drive(10);
            Console.WriteLine(sportcar.Fuel);
            Console.WriteLine(car.Fuel);
        }
    }
}
