﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=SMOKEDOUT\SQLEXPRESS;Database=MusicHub;Trusted_Connection=True";
    }
}
